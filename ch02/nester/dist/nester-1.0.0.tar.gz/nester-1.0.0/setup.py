from distutils.core import setup

setup(
  name = 'nester',
  version = '1.0.0',  
  py_modules = ['nester'],
  author = 'myton',
  author_email = 'tuszhangs@163.com',
  url = 'http://www.myton.com',
  description = 'A simaple printer of nested lists',
)
